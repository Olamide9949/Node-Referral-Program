# Invitation-System

<h3>Build a Referral System in Node-Express and Postgres</h3>
<img src="https://cdn-images-1.medium.com/max/2000/1*mnC2KfSvmfp3Nw3Tfz7mYA.png" />
<p>image source: https://medium.com/buttercloud-labs/how-to-build-a-referral-program-to-encourage-word-of-mouth-marketing-b77ff30f07d9</p>
<p> This repo is example written for article: 
  <a href="https://itnext.io/build-a-referral-system-in-node-express-and-postgres-da56fa4913d4"> Medium</a>
